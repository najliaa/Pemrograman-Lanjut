# NRP/NAMA: NAJLIA INTANI 2C223001
# TANGGAL: 14/10/2024
# DESKRIPSI: MENENTUKAN PEMBAGIAN KELAS MAHASISWA

def tentukan_kelas(nrp_akhir):
    # Fungsi ini menerima akhiran NRP dan menentukan kelas berdasarkan rentang NRP

    # Mengonversi akhiran NRP menjadi integer
    nrp_akhir = int(nrp_akhir)

    # Percabangan untuk menentukan kelas berdasarkan rentang NRP
    if 1 <= nrp_akhir <= 100:  # Jika NRP antara 001 dan 100
        if nrp_akhir % 2 == 0:  # Jika NRP genap
            return "K2"  # Kelas K2 untuk NRP genap
        else:  # Jika NRP ganjil
            return "K1"  # Kelas K1 untuk NRP ganjil
    elif 101 <= nrp_akhir <= 200:  # Jika NRP antara 101 dan 200
        if nrp_akhir % 2 == 0:  # Jika NRP genap
            return "K4"  # Kelas K4 untuk NRP genap
        else:  # Jika NRP ganjil
            return "K3"  # Kelas K3 untuk NRP ganjil
    elif 201 <= nrp_akhir <= 300:  # Jika NRP antara 201 dan 300
        if nrp_akhir % 2 == 0:  # Jika NRP genap
            return "K6"  # Kelas K6 untuk NRP genap
        else:  # Jika NRP ganjil
            return "K5"  # Kelas K5 untuk NRP ganjil
    elif nrp_akhir > 300:  # Jika NRP lebih dari 300
        if nrp_akhir % 2 == 0:  # Jika NRP genap
            return "K8"  # Kelas K8 untuk NRP genap
        else:  # Jika NRP ganjil
            return "K7"  # Kelas K7 untuk NRP ganjil
    else:
        return "NRP yang dimasukkan tidak valid"  # Jika NRP tidak dalam rentang yang ditentukan

# Prosedur utama untuk meminta input dari pengguna
def main():
    # Prosedur ini meminta input akhiran NRP dari pengguna dan menampilkan kelas yang sesuai
    nrp_akhir = input("Masukkan akhiran NRP: ")  # Meminta pengguna memasukkan akhiran NRP
    kelas = tentukan_kelas(nrp_akhir)  # Memanggil fungsi untuk menentukan kelas
    print(f"Mahasiswa masuk ke kelas {kelas}")  # Menampilkan kelas yang sesuai

# Memanggil prosedur utama
main()