# NRP/NAMA: NAJLIA INTANI 2C223001
# TANGGAL: 14/10/2024
# DESKRIPSI: MENENTUKAN BARANG YANG PALING MENENTUKAN TUAN RO

def hitung_keuntungan(harga_dasar, harga_jual):
    # Komentar: Fungsi ini menghitung keuntungan dengan cara mengurangi harga dasar dari harga jual
    return harga_jual - harga_dasar

# Menghitung keuntungan barang
def temukan_barang_paling_menguntungkan():
    # Komentar: Prosedur ini meminta input harga dasar dan harga jual dari pengguna untuk tiga barang
    harga_dasar_A = float(input("Masukkan harga dasar barang A: "))  # Variabel harga_dasar_A untuk menyimpan input harga dasar barang A
    harga_jual_A = float(input("Masukkan harga jual barang A: "))  # Variabel harga_jual_A untuk menyimpan input harga jual barang A
    keuntungan_A = hitung_keuntungan(harga_dasar_A, harga_jual_A)  # Variabel keuntungan_A untuk menyimpan hasil perhitungan keuntungan barang A

    harga_dasar_B = float(input("Masukkan harga dasar barang B: "))  # Variabel harga_dasar_B untuk menyimpan input harga dasar barang B
    harga_jual_B = float(input("Masukkan harga jual barang B: "))  # Variabel harga_jual_B untuk menyimpan input harga jual barang B
    keuntungan_B = hitung_keuntungan(harga_dasar_B, harga_jual_B)  # Variabel keuntungan_B untuk menyimpan hasil perhitungan keuntungan barang B

    harga_dasar_C = float(input("Masukkan harga dasar barang C: "))  # Variabel harga_dasar_C untuk menyimpan input harga dasar barang C
    harga_jual_C = float(input("Masukkan harga jual barang C: "))  # Variabel harga_jual_C untuk menyimpan input harga jual barang C
    keuntungan_C = hitung_keuntungan(harga_dasar_C, harga_jual_C)  # Variabel keuntungan_C untuk menyimpan hasil perhitungan keuntungan barang C

    # Menentukan barang paling menguntungkan
    if keuntungan_A > keuntungan_B and keuntungan_A > keuntungan_C:
        print("Barang yang harus ditawarkan adalah barang A")  # Jika keuntungan A lebih besar dari B dan C, maka barang A yang harus ditawarkan
    elif keuntungan_B > keuntungan_A and keuntungan_B > keuntungan_C:
        print("Barang yang harus ditawarkan adalah barang B")  # Jika keuntungan B lebih besar dari A dan C, maka barang B yang harus ditawarkan
    else:
        print("Barang yang harus ditawarkan adalah barang C")  # Jika keuntungan C lebih besar dari A dan B, maka barang C yang harus ditawarkan

temukan_barang_paling_menguntungkan()